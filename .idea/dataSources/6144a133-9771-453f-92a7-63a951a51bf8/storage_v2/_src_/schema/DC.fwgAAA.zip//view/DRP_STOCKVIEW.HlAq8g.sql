create view DRP_STOCKVIEW as
Select a.id ID,
       c.warecode WareCode,
       nvl(a.stockqty, 0) StockQty,
       nvl(b.purchaseqty, 0) PurchaseQty,
       nvl(c.orderqty, 0) OrderQty,
       nvl(c.frozenqty, 0) FrozenQty,
       (nvl(d.totalstockqty, 0) + nvl(b.purchaseqty, 0) -  nvl(c.frozenqty, 0)) ActiveQty,
       nvl(a.realactiveqty, 0) RealActiveQty,
       nvl(d.totalstockqty,0) TotalStockQty,
       nvl(d.totalstockqty,0) - nvl(c.frozenqty, 0)  ApprovingStock,
       d.orgstockqty,
       b.DeliverTime
  From om.om_stock c
  Left Join om.kc_stock a
    On c.warecode = a.warecode
  Left Join om.OM_PurchaseOrder b
    On c.warecode = b.warecode
  Left Join om.kc_orgstock d
    On c.warecode = d.warecode
    where c.warecode not in (
          select wl.Warecode   from  wms.wl_thirdcompanyware wl where wl.sellercode='f0445f5d-a570-4407-827d-f40dc4a0603e'
    )
  union
 select 111,sss.Warecode,sss.stockqty,0,0,0,sss.stockqty,sss.stockqty,sss.stockqty,sss.stockqty,sss.stockqty,SYSDATE  from  wms.wl_thirdcompanyware sss
 where sss.sellercode='f0445f5d-a570-4407-827d-f40dc4a0603e'
/

comment on column DRP_STOCKVIEW.ACTIVEQTY is '可用库存数量(totalstockqty+PurchaseQty-FrozenQty)'
/

comment on column DRP_STOCKVIEW.REALACTIVEQTY is '花都仓库实物库存'
/

comment on column DRP_STOCKVIEW.TOTALSTOCKQTY is '机构账面库存'
/

comment on column DRP_STOCKVIEW.APPROVINGSTOCK is '审批库存(TotalStockQty - FrozenQty)'
/

comment on column DRP_STOCKVIEW.ORGSTOCKQTY is '机构实物库存'
/

