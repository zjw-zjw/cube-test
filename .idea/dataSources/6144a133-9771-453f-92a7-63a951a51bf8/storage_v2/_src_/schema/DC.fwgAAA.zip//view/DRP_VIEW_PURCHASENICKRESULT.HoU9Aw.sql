create view DRP_VIEW_PURCHASENICKRESULT as
select n.actid ,n.buyernick
,decode( n.isdealy,0,'非延迟',1,'延迟单个',2,'延迟多个','未匹配' ) IsDelay
,decode( n.iseffet,'0','无效用户','1','有效用户','未匹配' ) IsEff
,t.tid ,t.payment
,decode(t.status,'TRADE_CLOSED','交易关闭','TRADE_FINISHED','交易完成','WAIT_BUYER_CONFIRM_GOODS','已发货待签收','TRADE_CLOSED_BY_TAOBAO','订单取消','TRADE_NO_CREATE_PAY','不能支付','WAIT_SELLER_SEND_GOODS','待卖家发货' ) status
,n.piresult ,n.created ,n.pitime
,t.created TradeCreateTime ,t.payed TradePayTime
 from  drp.drp_puarchasenick n
left join drp.drp_purchasenickresult t on (n.actid = t.actid and n.buyernick = t.nick )
/

