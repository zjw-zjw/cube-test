create view VI_MM_KATSUBMANAGE as
select p.prmcode,p.warecode,m.waremanagercode from OM.MM_KitSub P JOIN BASE.WI_WAREMANAWARERELATION M
ON P.WARECODE = M.WARESKUCODE


/

