create FUNCTION o2o_fn_calc_gvalue
(change_type in number, originl_g_value in number, change_value in number,remrk in nvarchar2) return number is 
new_value number;
begin
  if change_type in (1,2,5,6,7) then
     new_value := originl_g_value + change_value;
  elsif change_type in (3,4) and remrk = '取消订单退货返回成长值' then
     new_value := originl_g_value + change_value;
  elsif change_type in (3,4)
     new_value := originl_g_value - change_value;
  elsif change_type in (999) then
     new_value := originl_g_value - change_value;
  else
     new_value := originl_g_value;
  end if;
  if new_value < 0 then
    new_value := 0;
  end if;
return (new_value);
end o2o_fn_calc_gvalue;
/

