create view DC_UV_KC_PLACESTOCK as
select nvl(a.OrgCode, b.OrgCode) OrgCode,
   nvl(a.WhCode, b.WhCode) WhCode,
   nvl(a.PlaceCode, b.PlaceCode) PlaceCode,
   nvl(a.WareCode, b.WareCode) WareCode,
   nvl(a.Batchno, b.batchno) Batchno,
   nvl((a.PlaceCode || a.Batchno), (b.PlaceCode || b.Batchno)) PlaceCodeBatchno,
   nvl(a.expireddate, b.expireddate) expireddate,
   nvl(a.Productiondate, b.Productiondate) Productiondate,
   nvl(a.StockQty, 0) StockQty,
   nvl(b.sumQty, 0) OnWayStock,
   nvl(a.StockQty, 0) + nvl(b.sumQty, 0) as UsableQty
from wms.kC_PlaceStock a
full join (
	select orgcode,
		WhCode,
		PlaceCode,
		WareCode,
		batchno,
		EXPIREDDATE,
		Productiondate,
		sum(Qty * Directflag) sumQty,
		sum(case when directflag = -1 then qty *-1 else 0 end) minusQty,
		sum(case when directflag = 1 then qty else 0 end) PositiveOnWay
	from wms.KC_placeOnWayStock
	where Status = 0
	group by orgcode, WhCode, PlaceCode, WareCode, batchno, EXPIREDDATE, Productiondate
) b on a.WareCode=b.WareCode and a.PlaceCode=b.PlaceCode and a.Batchno=b.batchno and a.WhCode=b.WhCode and a.orgcode=b.orgcode
where a.StockQty>0
/

comment on table DC_UV_KC_PLACESTOCK is '商品货位库存视图(药企库存查询使用)'
/

