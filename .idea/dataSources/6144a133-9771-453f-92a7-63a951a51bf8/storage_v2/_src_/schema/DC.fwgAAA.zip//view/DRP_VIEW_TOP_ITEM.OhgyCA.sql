create view DRP_VIEW_TOP_ITEM as
select a.numiid,a.OuterId,a.title,a.approvestatus,a.nick, b.skuid,b.outerid as skuouterid,a.Created,a.Modified from DRP.DRP_TOP_ITEM a left join DRP.DRP_TOP_SKU b on a.numiid = b.numiid
/

