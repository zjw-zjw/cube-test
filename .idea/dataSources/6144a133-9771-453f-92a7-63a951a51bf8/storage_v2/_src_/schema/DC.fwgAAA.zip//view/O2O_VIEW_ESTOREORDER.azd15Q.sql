create view O2O_VIEW_ESTOREORDER as
select min(code) code,ordercode,CommodityCode,CommodityName,SettlementPrice,RetailPrice,RecommendedValue,sum(SettlementAmount) SettlementAmount,sum(RetailAmount) RetailAmount,sum(TotalRecommendedValue) TotalRecommendedValue,
OrderTime,Reviewer,min(AuditTime) AuditTime,(sum(SaleNumber) || '(' || max(SaleNumber) || sum(case when SaleNumber < 0 then SaleNumber end) || ')' ) SaleNumber,StoreCode,State
from o2o.E_StoreOrderSaleDetail
group by ordercode,CommodityCode,CommodityName,SettlementPrice,RetailPrice,RecommendedValue,OrderTime,Reviewer,StoreCode,State
/

