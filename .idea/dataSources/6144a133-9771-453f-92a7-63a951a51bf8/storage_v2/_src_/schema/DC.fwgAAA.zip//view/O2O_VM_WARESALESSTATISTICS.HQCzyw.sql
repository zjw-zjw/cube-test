create view O2O_VM_WARESALESSTATISTICS as
select
  RAWTOHEX(sys_guid()) as StatisticsId, pfc.OrderCode, pfcs.DetailId as OrderDetailId, pfcs.WareCode, s.WareName, wi.Model, wi.UnitCode, u.UnitName, wi.ManufacturerName, pfspws.ReCheckQty as Qty, pfcs.Price, o.CreateDate as OrderDate
    , pfe.DeliverDate as OutDate, o.CusCode, o.CusName, c.CusCode as ShopCode, c.CusName as ShopName, c.CustomerType as StoreType, c.ProviceCode as ProvinceCode, c.Province as ProvinceName, c.CityCode as CityCode, c.City as CityName, c.AreaCode as DistrictCode, c.Area as DistrictName
    , pfspws.BatchNo, wbned.ExpiredDate, wbned.ProductionDate, o.OrderStatus, o.OrderSource
from  (select ConsignCode, WareCode, BatchNo, Sum(ReCheckQty) as ReCheckQty from WMS.KC_PFSalePickWareSub group by ConsignCode, WareCode, BatchNo) pfspws
inner join (select ConsignCode, WareCode, max(DetailId) as DetailId, Round(sum(RealOutQty*AfterDisPrice)/decode(sum(RealOutQty), 0, 1, sum(RealOutQty)), 4) as Price from WMS.WL_PFConsignsub pfcs group by ConsignCode, WareCode) pfcs on pfcs.ConsignCode=pfspws.ConsignCode and pfcs.WareCode=pfspws.WareCode
inner join WMS.WL_PFConsign pfc on pfc.ConsignCode=pfcs.ConsignCode
inner join WMS.WL_PFEfficiency pfe on pfe.OrderCode = pfc.OrderCode and pfe.ConsignCode = pfc.ConsignCode
inner join wms.bd_WareBatchNoExpiredDate wbned on wbned.BatchNo = pfspws.BatchNo and wbned.WareCode = pfspws.WareCode
inner join WS.WS_Order o on o.OrderCode = pfc.OrderCode
inner join BASE.WI_WARESKU s on s.WareSkuCode = pfspws.WareCode
inner join BASE.WI_WAREINFO wi on wi.ProductCode = s.ProductCode
left join BASE.WI_UNIT u on u.UnitCode = wi.UnitCode
inner join WS.WS_Customer c on c.CusCode = o.CusCode
where pfc.Status in (80, 82, 85, 100) and o.OrderSource = 2
/

