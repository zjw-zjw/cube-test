create view V_DC_WI_ATTRVALUESTORE as
select Id,wareattrtype,wareattrcategory,wareattrname,wareattrvaluecode,productcode,wareattrcode ,to_char(wareattrvalue) wareattrvalue From base.wi_attrvaluestore  a
Where wareattrcode='285010'
/

