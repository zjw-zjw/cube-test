create view DC_UV_WARECATEGORY as
select 
	    warecategorycode,
	    warecategoryname,
	    waretypecode,
	    modifytime,
	    waretypename,
	    parentcode,
	    paths, pathname,
	    substr(paths, instr(paths,',',1,1)+1, instr(paths,',',1,2)-instr(paths,',',1,1)-1) as FirstCategoryCode,
	    substr(paths, instr(paths,',',1,2)+1, instr(paths,',',1,3)-instr(paths,',',1,2)-1) as SecondCategoryCode,
	    substr(paths, instr(paths,',',1,3)+1, instr(paths,',',1,4)-instr(paths,',',1,3)-1) as ThreeCategoryCode,
	    substr(paths, instr(paths,',',1,4)+1, instr(paths,',',1,5)-instr(paths,',',1,4)-1) as FourCategoryCode,
	    substr(paths, instr(paths,',',1,5)+1, instr(paths,',',1,6)-instr(paths,',',1,5)-1) as FiveCategoryCode,
	    waretypename as FirstCategoryName,
	    substr(pathname, instr(pathname,',',1,1)+1, instr(pathname,',',1,2)-instr(pathname,',',1,1)-1) as SecondCategoryName,
	    substr(pathname, instr(pathname,',',1,2)+1, instr(pathname,',',1,3)-instr(pathname,',',1,2)-1) as ThreeCategoryName,
	    substr(pathname, instr(pathname,',',1,3)+1, instr(pathname,',',1,4)-instr(pathname,',',1,3)-1) as FourCategoryName,
	    substr(pathname, instr(pathname,',',1,4)+1, instr(pathname,',',1,5)-instr(pathname,',',1,4)-1) as FiveCategoryName
	from (
	    select level,
	        c.warecategorycode,
	        c.warecategoryname,
	        c.waretypecode,
	        c.modifytime,
	        w.waretypename,
	        c.parentcode,
	        sys_connect_by_path(c.parentcode, ',') || ',' paths,
	        substr((sys_connect_by_path(c.warecategoryname, ',') || ','), 1, instr((sys_connect_by_path(c.warecategoryname, ',') || ','), ',',-2)) pathname
	    from base.wi_warecategory c
	    join base.wi_waretype w on c.waretypecode = w.waretypecode
	    connect by prior c.warecategorycode = c.parentcode
	    start with c.waretypecode = c.parentcode
	)
/

comment on table DC_UV_WARECATEGORY is '用于抽取数据到药企kudu时获取商品类目'
/

