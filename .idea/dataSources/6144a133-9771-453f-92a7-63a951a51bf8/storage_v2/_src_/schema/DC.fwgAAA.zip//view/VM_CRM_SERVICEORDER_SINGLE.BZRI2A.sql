create view VM_CRM_SERVICEORDER_SINGLE as
select od.cuscode,odd.warecode,odd.qty,odd.ordercode,od.createdate,odd.ordertime,gm.groupid,oad.mobilephone,oad.telephone,od.ordersource,od.orderstatus,ost.finishdate,ost.outdate,od.orderchannel
from crm.CRM_GroupMembers gm join om.om_order od on gm.cuscode = od.cuscode
join om.om_orderdetail odd on od.ordercode = odd.ordercode
join om.om_orderaddress oad on oad.ordercode = odd.ordercode
join om.om_orderstatus ost on oad.ordercode = ost.ordercode
/

