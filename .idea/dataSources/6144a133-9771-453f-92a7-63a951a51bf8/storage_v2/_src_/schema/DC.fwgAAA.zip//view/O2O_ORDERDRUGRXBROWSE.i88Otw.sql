create view O2O_ORDERDRUGRXBROWSE as
select
       o.shopcode,
       o.ordercode,
       o.createdate,
       o.cuscode,
       obd.warecode,
       ware.warename,
       ware.model,
       ware.manufacturername,
       obd.batchno,
       obd.qty,
       o.orderstatus,
       nvl(pcs.status, 0) as finishStatus,
       pcs.subid,
       pcs.Dosage,
       pcs.hospital,
       pcs.doctorsno,
       pcs.doctors,
       pcs.buypeople,
       pcs.age,
       pcs.telphone,
       pcs.deploypeople,
       pcs.checkpharmacist,
       pcs.verificationpeople,
       pcs.department,
       pcs.address,
       pcs.diseases,
       pcs.sex,
       pcs.rxsales,
       pcs.rxtype,
       pcs.idcard,
       pcs.rxattachment,
       o.sales,
       o.salescode,
       o.creatorcode
  from om.om_order o
  --join om.om_orderdetail od
    --on o.ordercode = od.ordercode
  join store.o2o_orderbatchdetail obd
    on o.ordercode = obd.ordercode
  join store.o2o_wareinfo ware
    on obd.warecode = ware.warecode
   and o.shopcode = ware.shopcode
   --and od.warecode = obd.warecode
  left join store.o2o_prescriptionchecksub pcs
    on pcs.ordercode = o.ordercode
   and pcs.warecode = obd.warecode
  left join
  (
      --商品要全部退货就踢掉，部分退货还是要上传处方笺
      select t1.ordercode,t1.warecode,t1.rtqty,t.qty
      from
      (
        select r.ordercode,rt.warecode,sum(rt.qty) rtqty
        from om.re_service r
        join om.Re_Servicedetailrtn rt on r.servicecode=rt.servicecode
        where r.returntype=7 and r.ischeck=1 and r.Isrtnware=1
        group by r.ordercode,rt.warecode
      ) t1
      join
      (
         select obd.ordercode,obd.warecode,sum(obd.qty) qty
         from store.o2o_orderbatchdetail obd
         group by obd.ordercode,obd.warecode
      ) t on t1.ordercode=t.ordercode and t1.warecode=t.warecode
      where t.qty<=t1.rtqty
  ) tb on o.ordercode=tb.ordercode and obd.warecode=tb.warecode
 where ware.drugtype = 0 and tb.warecode is null
/

