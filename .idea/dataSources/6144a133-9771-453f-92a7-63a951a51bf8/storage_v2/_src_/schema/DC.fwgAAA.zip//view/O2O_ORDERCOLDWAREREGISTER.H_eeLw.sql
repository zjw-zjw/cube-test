create view O2O_ORDERCOLDWAREREGISTER as
Select                 T1.ORDERCODE                 ,
                       T1.Detailid as OrderDetailId ,
                       T2.CREATEDATE                ,
                       T2.SHOPCODE                  ,
                       T1.WARECODE                  ,
                       T3.WARENAME                  ,
                       T3.MODEL                     ,
                       T1.BATCHNO                   ,
                       T3.ManufacturerName          ,
                       T3.UnitCode                  ,
                       T3.UnitName                  ,
                       T3.IsEphedrin                ,
                       T1.QTY                       ,
                       T2.SALES                     ,
                       T4.ID                        ,
                       T4.SALESTEMP            	  	,
                       T4.CUSTOMERTIME              ,
                       T4.ICEMODEL                	,
                       T4.ICEQTY              	  	,
                       T4.ISTEMPREMIND              ,
                       T4.CUSTOMERNAME              ,
                       T4.CWSALES                   ,
                       nvl(T4.STATUS,0) as STATUS   ,
                       T3.IsColdWare                ,
                       T3.IsRx                      ,
                       T2.ORDERSTATUS               ,
                       T3.GSPCategory
                  From STORE.O2O_ORDERBATCHDETAIL T1
                  Join OM.OM_ORDER T2
                    on T1.ORDERCODE = T2.ORDERCODE
                  left Join STORE.O2O_ORDERCOLDWARE T4
                    on T1.ORDERCODE = T4.ORDERCODE
                   and T1.WARECODE = T4.WARECODE
                  Join O2O_GETWAREDC T3
                    on T1.WARECODE = T3.WARECODE
                   and T2.SHOPCODE = T3.ORGCODE
                   and T1.BATCHNO = T3.BATCHNO
                  where T3.IsColdWare=1
                  and 1=0


/

