create view DRP_VIEW_SHOPINFO as
select s.nick as ShopCode , s.NICK as ShortName,p.platformname from drp.DRP_Store s ,drp.DRP_Platform p
where s.platfromid = p.platfromid
union all
select cast(SHOPCODE as nvarchar2(50)) as ShopCode ,SHORTNAME as ShortName,null as platformname from o2o.O2O_SHOPINFO
/

