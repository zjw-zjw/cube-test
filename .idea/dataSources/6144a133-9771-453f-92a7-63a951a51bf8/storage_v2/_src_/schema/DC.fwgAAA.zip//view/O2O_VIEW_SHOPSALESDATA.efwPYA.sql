create view O2O_VIEW_SHOPSALESDATA as
select  s.shopname,s.shopcode,s.introducedphone, sum(t.apppayamt)  apppayamt,t.STATUS
 from o2o.O2O_SHOPINFO s inner join ws.WS_CUSTOMER c on s.shopcode = c.externalcuscode inner join  ws.WS_PAYAPP t on c.cuscode = t.cuscode
 group by s.shopname,s.shopcode,s.introducedphone,t.STATUS order by apppayamt desc
/

