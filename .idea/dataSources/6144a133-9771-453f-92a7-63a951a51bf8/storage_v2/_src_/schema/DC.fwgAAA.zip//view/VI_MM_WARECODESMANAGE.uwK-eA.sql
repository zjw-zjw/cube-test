create view VI_MM_WARECODESMANAGE as
select p.prmcode,p.warecode,m.waremanagercode from OM.VI_MM_PromoteWareCodes P JOIN BASE.WI_WAREMANAWARERELATION M
ON P.WARECODE = M.WARESKUCODE


/

