create view MYVIEW as
select r.cuscode from om.om_order r left join  om.om_orderdetail il on r.ordercode = il.ordercode
where r.cuscode ='322'


/

