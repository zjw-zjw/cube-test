create view OM_INVOICEPRINTVIEW as
Select A.ORDERCODE ORDERCODE,
       A.CUSCODE,
       A.CUSNAME InvoiceCusName,
       A.NETAMT,
       A.CREATEDATE CREATEDATE,
       A.ORDERDESC REMARK,
       B.TITLE,
       B.CREATEDATE INVDATE,
       decode(B.STATUS, '1', '是', '否') STATUS,
       B.EXPRESSBILLCODE,
       B.EXPRESSCOMPANY,
       C.INVOICEAMOUNT amt,
       C.WARECODE,
       C.QTY,
       NVL(C.PRICE, 0) - NVL(C.DISPRICE, 0) Price,
       D.WARENAME,
       E.ACCEPTER,
       (Case
         When E.TELEPHONE Is Null Then
          E.MOBILEPHONE
         Else
          E.TELEPHONE
       End) MOBILEPHONE,
       E.PROVINCE || E.CITY || E.DISTRICT || E.ADDRESS As ADDRESS,
       (Case
         When (Select Count(1)
                 From WMS.IV_INVOICEALONEITEM
                Where WARECODE = C.WARECODE) > 0 Then
          D.WARENAME
         Else
          F.ITEMNAME
       End) ITEMNAME,
       (Case
         When (Select Count(1)
                 From WMS.IV_INVOICEALONEITEM
                Where WARECODE = C.WARECODE) > 0 Then
          G.UNITNAME
         Else
          F.UNITNAME
       End) UNITNAME
  From OM.OM_ORDER A
  Left Join OM.OM_INVOICE B
    On A.ORDERCODE = B.ORDERCODE
  Left Join OM.OM_ORDERDETAIL C
    On A.ORDERCODE = C.ORDERCODE
  Left Join BASE.WI_WARESKU D
    On C.WARECODE = D.WARESKUCODE
  Left Join OM.OM_ORDERADDRESS E
    On A.ORDERCODE = E.ORDERCODE
  Left Join WMS.IV_INVOICEITEM F
    On C.INVOICECONTENTCODE = F.ITEMCODE
  Left Join WMS.IV_INVOICEALONEITEM G
    On C.WARECODE = G.WARECODE
 Where A.INVOICETYPE = 1


/

