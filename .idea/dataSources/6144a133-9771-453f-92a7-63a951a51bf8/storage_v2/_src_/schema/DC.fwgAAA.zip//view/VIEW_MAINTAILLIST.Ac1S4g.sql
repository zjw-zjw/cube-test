create view VIEW_MAINTAILLIST (WARESKUCODE) as
select distinct(a.wareskucode) from base.wi_waresku a
inner join base.wi_wareinfo b on a.productcode=b.productcode
where 1=1
and b.gspcategory in (
select distinct(a.gspcategorycode) from base.wi_gspcategory a where 1=1
and a.gspcategorycode='77600030' and a.ISDELETE=0
union
select a.gspcategorycode from base.wi_gspcategory a where 1=1
and a.parentcode='77600030' and a.ISDELETE=0
union
 select a.gspcategorycode from base.wi_gspcategory a where 1=1
and a.parentcode in(select a.gspcategorycode from base.wi_gspcategory a where 1=1
and a.parentcode='77600030') and a.ISDELETE=0
union
select a.gspcategorycode from base.wi_gspcategory a where 1=1
and a.parentcode in (select a.gspcategorycode from base.wi_gspcategory a where 1=1
and a.parentcode in(select a.gspcategorycode from base.wi_gspcategory a where 1=1
and a.parentcode='77600030')) and a.ISDELETE=0
)
/

