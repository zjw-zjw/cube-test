create view O2O_VIEW_ESTOREFINANCIAL as
select ShopName,ShopCode,CmpName,
    sum(case when STATUS=0 then RecommendAmount else null end) UnfinishedAmount,
    sum(case when STATUS=1 then RecommendAmount else null end) FinishAmount  from o2o.E_STORESTATISTICS
    group by ShopName,ShopCode,CmpName
/

