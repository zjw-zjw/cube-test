create view DRP_VIEW_SHELFDOWN as
select  a.Mid,a.Platformname,a.Platformcode,a.Storecode,a.Storename,a.Itemoutid,a.Principal,a.Principallogin,a.Mealitemcode,
a.Stockrule,a.Stockwarn,a.Waretype,a.Wareskucode,a.Warename,b.Status,b.Editdate,c.ApprovingStock
,CASE when a.platformcode = 'YFW' and ((c.ApprovingStock * (a.stockrule/100)) - a.stockwarn) > 0 then '1' WHEN a.platformcode != 'YFW' and c.ApprovingStock > a.Stockwarn THEN '1'  ELSE '0' END CanPutaway
 from
  DRP.DRP_ITEM_MAPPING a inner join  DRP.DRP_ITEM_SHELFDOWN b on a.mid = b.mid
  inner join (select d.mid,  ceil(min(c.ApprovingStock / d.detailnum)) ApprovingStock from DRP.DRP_ITEM_DETAILS d  inner join dc.drp_stockview  c on d.wareskucode = c.warecode
 group by d.mid)  c on a.mid = c.mid where a.ISSHELFDOWN = 0
/

