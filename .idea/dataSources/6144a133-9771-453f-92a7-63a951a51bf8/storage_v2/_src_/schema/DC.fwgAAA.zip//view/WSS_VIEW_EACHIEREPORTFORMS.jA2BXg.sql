create view WSS_VIEW_EACHIEREPORTFORMS as
select
1 as Sou,
k.id as ID,
k.warecode,
k.warecode as EF_WARECODE,
k.ordercode as EF_ORDERCODE,
k.qty as EF_QTY,
0 as EF_Reqty,
l.price as EF_PRICE,
l.disprice as EF_DISPRICE,
d.cuscode as EF_CUSCODE,
k.orderdetailid as EF_DetailId,
null as EP_WARECODE,
null as EP_ORDERCODE,
0 as EP_QTY,
0 as EP_Reqty,
0 as EP_PRICE,
0 as EP_DISPRICE,
null as EP_CUSCODE,
w.CostPrice,
k.modifydate as createdate
from om.OM_ORDERDETAILSTOCK k 
 join OM.OM_ORDERDETAIL l on k.ordercode=l.ordercode and k.orderdetailid=l.detailid
 join base.wi_waresku w on k.warecode=w.wareskucode
 join OM.OM_ORDER d on k.ordercode=d.ordercode
where k.detailtype=4 and k.status!=2 and d.ordersource=53 
union all (select 
0 as Sou,
s.id as ID,
s.warecode,
null as EF_WARECODE,
null as EF_ORDERCODE,
0 as EF_QTY,
0 as EF_Reqty,
0 as EF_PRICE,
0 as EF_DISPRICE,
null  as EF_CUSCODE,
null as EF_DetailId,
s.warecode as EP_WARECODE,
s.ordercode as EP_ORDERCODE,
s.recheckqty as EP_QTY,
s.salesreturnqty as EP_Reqty,
s.price as EP_PRICE,
s.disprice as EP_DISPRICE,
s.cuscode as EP_CUSCODE,
w.CostPrice,
s.CreateDate
from ws.WS_OUTINVOICEWAREDETAIL s 
join base.wi_waresku w on s.warecode=w.wareskucode
join WS.WS_ORDER d on s.ordercode=d.ordercode
where d.ordersource=2)
/

