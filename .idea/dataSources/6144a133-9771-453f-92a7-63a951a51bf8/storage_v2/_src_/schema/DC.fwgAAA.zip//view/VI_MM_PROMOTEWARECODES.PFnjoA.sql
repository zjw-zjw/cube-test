create view VI_MM_PROMOTEWARECODES as
SELECT "PRMCODE","WARECODE" FROM (
SELECT prmcode,nodeCode WareCode from OM.MM_WareConfig wareConfig WHERE  wareConfig.nodetype = 1
UNION ALL
SELECT prmcode,wareskucode WareCode FROM OM.MM_WareConfig cnConfig JOIN  base.wi_warechannelrelation channel ON cnConfig.Nodecode = channel.webchannelcode
WHERE  channel.webchannelcode = cnConfig.nodecode AND cnConfig.nodetype = 2
UNION ALL
SELECT prmcode,wareskucode WareCode FROM OM.MM_WareConfig skuConfig JOIN  base.wi_waresku sku  ON skuConfig.Nodecode = sku.department
WHERE sku.department = skuConfig.nodecode AND skuConfig.nodetype = 3
) T WHERE NOT EXISTS (SELECT WareCode FROM OM.MM_WareBlackList B WHERE T.WARECODE = B.WARECODE AND T.PRMCODE = B.PRMCODE)


/

