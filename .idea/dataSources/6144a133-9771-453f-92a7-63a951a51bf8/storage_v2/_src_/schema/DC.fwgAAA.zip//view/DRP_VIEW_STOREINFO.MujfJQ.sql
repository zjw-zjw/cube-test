create view DRP_VIEW_STOREINFO as
select p.platformcode,p.platformname,p.key,p.secret,p.oauthurl,p.apiurl,p.jdpdomain,s."STOREID",s."PLATFROMID",s."OUTERID",s."SUBOUTERID",s."NICK",s."SUBNICK",s."ACCESSTOKEN",s."REFRESHKEY",s."EXPIRES_IN",s."R1_EXPIRES_IN",s."R2_EXPIRES_IN",s."RE_EXPIRES_IN",s."W2_EXPIRES_IN",s."W1_EXPIRES_IN",s."TOKEN_TYPE",s."USESTATE",s."CREATED",s."MODIFIED"
,s."CUSTOMERCODE", s.OmsCusSource from drp.DRP_Store s ,drp.DRP_Platform p
where s.platfromid = p.platfromid
with read only
/

