create view O2O_ORDERRXREGISTER as
Select T1.ORDERCODE     ,
  T2.Cuscode            ,
  T2.CREATEDATE         ,
  T2.SHOPCODE           ,
  T1.WARECODE           ,
  T3.WARENAME           ,
  T3.MODEL              ,
  T1.BATCHNO            ,
  T1.QTY                ,
  T4.DOSAGE             ,
  T4.HOSPITAL           ,
  T4.DOCTORS            ,
  T4.DOCTORSNO          ,
  T4.BUYPEOPLE          ,
  T4.AGE                ,
  T4.DISEASES           ,
  T4.DEPLOYPEOPLE       ,
  T4.CHECKPHARMACIST    ,
  T4.VERIFICATIONPEOPLE ,
  T4.DEPARTMENT         ,
  T4.ADDRESS            ,
  nvl(T4.STATUS,0) as STATUS,
  nvl(T4.Printstatus,0) as PrintStatus,
  T4.ID                 ,
  T2.SALES              ,
  T2.Salescode          ,
  T5.Workno             ,
  T4.TELPHONE           ,
  T4.SEX                ,
  T4.Rxsales            ,
  T4.Idcard             ,
  T3.IsRx               ,
  T2.ORDERSTATUS        ,
  T3.GSPCategory        ,
  T2.Creatorcode        ,
  T3.Manufacturername
From STORE.O2O_ORDERBATCHDETAIL T1
Join OM.OM_ORDER T2
on T1.ORDERCODE = T2.ORDERCODE
left Join STORE.O2O_ORDERRX T4
on T1.ORDERCODE = T4.ORDERCODE
and T1.WARECODE = T4.WARECODE
and T1.BATCHNO = T4.BATCHNO
Join store.o2o_wareinfo T3
on T1.WARECODE = T3.WARECODE
and T2.SHOPCODE = T3.Shopcode
left join STORE.o2o_user_workno T5 on T2.Shopcode=T5.Orgcode and T2.Salescode=T5.Loginname
left join
(
    --商品要全部退货就踢掉，部分退货还是要上传处方笺
    select t1.ordercode,t1.warecode,t1.rtqty,t.qty
    from
    (
      select r.ordercode,rt.warecode,sum(rt.qty) rtqty
      from om.re_service r
      join om.Re_Servicedetailrtn rt on r.servicecode=rt.servicecode
      where r.returntype=7 and r.ischeck=1 and r.Isrtnware=1
      group by r.ordercode,rt.warecode
    ) t1
    join
    (
       select obd.ordercode,obd.warecode,sum(obd.qty) qty
       from store.o2o_orderbatchdetail obd
       group by obd.ordercode,obd.warecode
    ) t on t1.ordercode=t.ordercode and t1.warecode=t.warecode
    where t.qty<=t1.rtqty
) tb on T2.ordercode=tb.ordercode and T1.warecode=tb.warecode
Where t3.GSPCategory<>'77600040' and (T3.Drugtype is null or T3.Drugtype=1) and tb.warecode is null
/

