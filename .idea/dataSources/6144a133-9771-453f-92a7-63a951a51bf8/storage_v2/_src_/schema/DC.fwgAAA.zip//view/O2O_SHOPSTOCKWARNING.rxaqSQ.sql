create view O2O_SHOPSTOCKWARNING as
select rownum as rownumber, rowresult."SHOPNAME",rowresult."SHOPCODE",rowresult."WARECODE",rowresult."WARENAME",rowresult."MODEL",rowresult."MANUFACTURERNAME",rowresult."SALESPRICE",rowresult."WARESTATUS",rowresult."MAXQTY",rowresult."SAFEQTY",rowresult."MINQTY",rowresult."STOCKQTY",rowresult."STATUSNAME"
         from (select tempresult.*, case when stockqty<=0 then '库存不足' when stockqty<tempresult.MinQty then '库存不足' when stockqty>tempresult.MaxQty then '库存充足' else '库存安全' end as statusname from (
         select tempqty.shopname, tempqty.shopcode, tempqty.warecode, tempqty.warename, tempqty.model, tempqty.manufacturername, tempqty.SalesPrice, tempqty.WareStatus,
        case when (tempqty.dayqty * 30)>0 and (tempqty.dayqty * 30)<1 then 1 else round(tempqty.dayqty * 30) end as MaxQty,
                case when (tempqty.dayqty * 15)>0 and (tempqty.dayqty * 15)<1 then 1 else round(tempqty.dayqty * 15) end as SafeQty,
                case when (tempqty.dayqty * 7)>0 and (tempqty.dayqty * 7)<1 then 1 else round(tempqty.dayqty * 7) end as MinQty, tempqty.stockqty
         from (select shopinfo.shopname, shopinfo.shopcode, ssc.warecode, ware.warename, ware.model, ware.manufacturername, ware.SalesPrice, ware.Status as WareStatus, round(ssc.salesqty / ssc.Days,4) as dayqty, stock.stockqty
         from (select ssb.orgcode, ssb.warecode, sum(ssb.qty) as salesqty, tempday.Days
         from STORE.O2O_SHOPSTOCKBOOK ssb, (select StartDate, EndDate, (EndDate - StartDate) as Days from (select to_date(to_char(trunc(add_months(last_day(sysdate), -4) + 1), 'yyyy-mm-dd'), 'yyyy-mm-dd') as StartDate, to_date(to_char(last_day(add_months(last_day(sysdate), -1)), 'yyyy-mm-dd'), 'yyyy-mm-dd') as EndDate from dual) td) tempday
         where ssb.sheetclass = 'OM_ORDER' and ssb.DirectFlag = -1 /* and {ShopCodeFilter} */ and (ssb.accdate >= tempday.StartDate and ssb.accdate <= tempday.EndDate)
         group by ssb.orgcode, ssb.warecode, tempday.Days) ssc
         left join STORE.O2O_SHOPSTOCK stock on ssc.orgcode = stock.orgcode and ssc.warecode = stock.warecode
         left join DC.O2O_WAREDC ware on ssc.orgcode = ware.storescode and ssc.warecode = ware.warecode
         left join STORE.O2O_SHOPINFO shopinfo on ssc.orgcode = shopinfo.shopcode
         /* where {WareCodeFilter} and {WareNameFilter} and {ManufacturerNameFilter} */
         order by ssc.salesqty desc) tempqty) tempresult) rowresult
         /* where {StatusNameFilter} */


/

