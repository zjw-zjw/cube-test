create view O2O_GETWAREDC as
select w.WareCode,
       w.WareName,
       w.IsRx,
       w.ManufacturerName,
       w.Model,
       w.price,
       w.SalesPrice,
       w.ShopPrice,
       w.StoresCode as OrgCode,
       wt.batchno,
       wt.stockqty,
       wt.expireddate,
       wt.productiondate,
       w.GSPCategory,
       case when wc.id is null then w.BarCode else REPLACE(w.WareCode,'CL','') end as BarCode,
       w.unitcode,
       w.unitname,
       w.ismrelease,
       case when wc.id is null then 0 else 1 end as IsWareConvert,            --是否拆零药品
       case when ew.warecode is null then 0 else 1 end as IsEphedrin,         --是否含麻黄碱
       case when w.StorageProperties in (3,4) then 1 else 0 end as IsColdWare --是否冷藏药品
 from O2o_WareDC w
 inner join store.o2o_whstock wt on w.StoresCode = wt.orgcode and w.WareCode = wt.warecode
 left join store.O2O_WARECONVERT wc on w.StoresCode = wc.orgcode and w.WareCode = wc.NewWareCode and wt.BatchNO = wc.BatchNO
 left join  store.UV_O2O_GSPPROSTOPSUB b on w.WareCode =b.warecode and wt.batchno=b.batchno
 left join store.UV_O2O_CLOSEEXPIRATIONSTOPSUB c on wt.orgcode = c.shopcode and w.warecode = c.warecode and wt.batchno = c.batchno
 left join store.Bd_Ephedrinware ew on w.WareCode=ew.warecode
 where w.Status not in (3, 4, 5) and w.IsShelfDown=0 and b.warecode is null and c.warecode is null and ((wc.AUDITTYPE=1 and wc.SHEETTYPE=3) or wc.id is null)


/

