create view OM_PURCHASEORDER as
Select b.warecode WareCode,
      Case
         When (Sum(b.orderqty - b.inqty)) > 0 Then
          (Sum(b.orderqty - b.inqty))
         Else
          0
       End As  PurchaseQty,
       Min(b.delivertime) DeliverTime
  From po.po_purorder a
  Join po.po_purordertotalsub b
    On a.sheetcode = b.sheetcode
 Where a.status in(100, 15) and (b.state = 0 Or b.state Is Null) and a.sheettype <>4
 Group By b.warecode


/

