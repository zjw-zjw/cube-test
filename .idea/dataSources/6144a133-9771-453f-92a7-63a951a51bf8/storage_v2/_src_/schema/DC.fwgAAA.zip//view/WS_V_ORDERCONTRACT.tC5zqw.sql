create view WS_V_ORDERCONTRACT as
select distinct d.ordercode from ws.ws_orderdetail d
where   (

   d.qty> (select sum(qty) from   WS.WS_SALESCONTRACTDETAIL a
                           join  ws.ws_salescontract b on a.salescontractid=b.id
                           where b.status<>4 and  a.orderdetailid=d.detailid  group by orderdetailid)

 or  detailid not in (select orderdetailid from   WS.WS_SALESCONTRACTDETAIL a
                      join  ws.ws_salescontract b on a.salescontractid=b.id
                      where b.status<>4 and  a.ordercode=d.ordercode )
 )
/

