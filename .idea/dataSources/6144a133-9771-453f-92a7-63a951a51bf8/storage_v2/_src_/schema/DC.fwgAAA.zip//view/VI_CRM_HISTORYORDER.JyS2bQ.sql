create view VI_CRM_HISTORYORDER as
Select T2.Cuscode,T2.Createdate,T4.Ordertime,T4.QTY,T3.Status,T3.GroupId,T4.Warecode
From OM.Om_Orderdetail T4
inner join CRM.CRM_WARESHISTORY T3 on T3.WARECODE = T4.Warecode
inner join  OM.OM_ORDER T2 on T2.Ordercode = T4.Ordercode
/

