create view CRM_V_MYCUSTOMERS_UNION as
SELECT "CUSID",
       "CUSCODE",
       "LOGINNAME",
       "FOLLOWTIME",
       "ESTIMATETIME",
       "CREATOR",
       "CREATORCODE",
       "CREATETIME",
       "ISTEMP",
       "FOLLOWSTATUS"
  FROM (SELECT MC.CUSID,
               MC.CUSCODE,
               MC.LOGINNAME,
               MC.FOLLOWTIME,
               MC.ESTIMATETIME,
               MC.CREATOR,
               MC.CREATORCODE,
               MC.CREATETIME,
               MC.ISTEMP,
               0 AS FOLLOWSTATUS
          FROM CRM.CRM_MYCUSTOMERS MC
         WHERE NOT EXISTS (SELECT 1
                  FROM CRM.CRM_CUSTOMERMAP MQ
                 WHERE MQ.CUSCODESLAVE = MC.CUSCODE
                   AND (MQ.ISREMOVEBIND = 0
                    OR MQ.ISREMOVEBIND IS NULL))
           AND NOT EXISTS
         (SELECT 1
                  FROM CRM.CRM_CUSTOMERSERVICE CS
                 WHERE CS.ISDENIALSERVICE = 1
                   AND CS.CUSCODE = MC.CUSCODE)
           AND MC.ISTEMP = 0
           AND (MC.FOLLOWTIME IS NULL OR (MC.FOLLOWTIME < SYSDATE - 45 OR
               MC.FOLLOWTIME < MC.CREATETIME))
         ORDER BY CREATETIME DESC) T1
UNION ALL
SELECT "CUSID",
       "CUSCODE",
       "LOGINNAME",
       "FOLLOWTIME",
       "ESTIMATETIME",
       "CREATOR",
       "CREATORCODE",
       "CREATETIME",
       "ISTEMP",
       "FOLLOWSTATUS"
  FROM (SELECT MC.CUSID,
               MC.CUSCODE,
               MC.LOGINNAME,
               MC.FOLLOWTIME,
               MC.ESTIMATETIME,
               MC.CREATOR,
               MC.CREATORCODE,
               MC.CREATETIME,
               MC.ISTEMP,
               1 AS FOLLOWSTATUS
          FROM CRM.CRM_MYCUSTOMERS MC
         WHERE NOT EXISTS (SELECT 1
                  FROM CRM.CRM_CUSTOMERMAP MQ
                 WHERE MQ.CUSCODESLAVE = MC.CUSCODE
                   AND (MQ.ISREMOVEBIND = 0
                    OR MQ.ISREMOVEBIND IS NULL))
           AND MC.ISTEMP = 0
           AND (MC.FOLLOWTIME >= MC.CREATETIME AND
               MC.FOLLOWTIME >= SYSDATE - 45)
           AND NOT EXISTS (SELECT 1
                  FROM CRM.CRM_CUSTOMERSERVICE CS
                 WHERE CS.ISDENIALSERVICE = 1
                   AND CS.CUSCODE = MC.CUSCODE)) T2
UNION ALL
SELECT "CUSID",
       "CUSCODE",
       "LOGINNAME",
       "FOLLOWTIME",
       "ESTIMATETIME",
       "CREATOR",
       "CREATORCODE",
       "CREATETIME",
       "ISTEMP",
       "FOLLOWSTATUS"
  FROM (SELECT MC.CUSID,
               MC.CUSCODE,
               MC.LOGINNAME,
               MC.FOLLOWTIME,
               MC.ESTIMATETIME,
               MC.CREATOR,
               MC.CREATORCODE,
               MC.CREATETIME,
               MC.ISTEMP,
               2 AS FOLLOWSTATUS
          FROM CRM.CRM_MYCUSTOMERS MC
         WHERE NOT EXISTS (SELECT 1
                  FROM CRM.CRM_CUSTOMERMAP MQ
                 WHERE MQ.CUSCODESLAVE = MC.CUSCODE
                   AND (MQ.ISREMOVEBIND = 0
                    OR MQ.ISREMOVEBIND IS NULL))
           AND MC.ISTEMP = 0
           AND EXISTS (SELECT 1
                  FROM CRM.CRM_CUSTOMERSERVICE CS
                 WHERE CS.ISDENIALSERVICE = 1
                   AND CS.CUSCODE = MC.CUSCODE)) T3
/

