create view VI_WAREMANAWARE as
select distinct r.wareskucode,r.waremanagercode,r.waremanager,2 NodeType,w.webchannelcode

NodeCode from base.WI_WareManaWareRelation r join base.WI_WareChannelRelation w
on r.wareskucode =w.wareskucode union all
select distinct r.wareskucode,r.waremanagercode,r.waremanager,3 NodeType,k.department NodeCode

from base.WI_WareManaWareRelation r join base.wi_waresku k
on r.wareskucode =k.wareskucode


/

