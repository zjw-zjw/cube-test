create view VIEW_DRP_ORDERTHIRDWARE as
select  d.detailid,d.ordercode,d.origindetailid,o.originorderid,w.companycode
   from wms.wl_thirdcompanyware w
   inner join om.om_orderdetail d on(w.warecode = d.warecode)
   inner join om.om_order o on ( d.ordercode = o.ordercode and o.sellercode = w.sellercode)


/

