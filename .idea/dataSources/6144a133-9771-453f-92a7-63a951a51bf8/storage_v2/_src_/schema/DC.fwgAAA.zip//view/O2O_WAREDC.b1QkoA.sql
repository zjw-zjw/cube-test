create view O2O_WAREDC as
select sku.WareSkuCode as WareCode,
       info.WareName as WareName,
       info.DrugName as DrugName,
       info.PinYin as PinYin,
       info.EnglishName as EnglishName,
       info.BrandCode as BrandCode,
       info.WareGeneralName as WareGeneralName,
       info.ManufacturerName as ManufacturerName,
       info.ManufacturerAbbreviation as ManufacturerAbbreviation,
       info.CategoryCode as CategoryCode,
       info.UnitCode as UnitCode,
       u.unitname as unitName,
       info.Model as Model,
       info.Packing as Packing,
       info.GrossWeight as GrossWeight,
       info.SizeLong as SizeLong,
       info.SizeWide as SizeWide,
       info.SizeHigh as SizeHigh,
       info.MinPrice as MinPrice,
       info.MaxPrice as MaxPrice,
       info.MarketPrice as MarketPrice,
       '' as Instructions,
       info.BarCode as BarCode,
       info.IsInFlammable as IsInFlammable,
       info.GSPCategory as GSPCategory,
       info.IsSubmitPaper as IsSubmitPaper,
       info.IsValuable as IsValuable,
       info.FirstCampFileNumber as FirstCampFileNumber,
       info.RegisTrationNumber as RegisTrationNumber,
       info.QualityStandard as QualityStandard,
       info.StorageConditions as StorageConditions,
       info.StorageProperties as StorageProperties,
       info.ForbiddenCash as ForbiddenCash,
       info.PeriodValidity as PeriodValidity,
       info.IsStop as IsStop,
       info.IsRx as IsRx,
       info.ForPeople as ForPeople,
       info.productcode as ProductCode,
       sku.Status as Status,
       sku.ColorCode as ColorCode,
       sku.SpecCode as SpecCode,
       sku.IsSelfSale as IsSelfSale,
       sku.SellerCode as SellerCode,
       sku.SellerSkuCode as SellerSkuCode,
       sku.department as Department,
       sku.ismrelease as IsMRelease,
       sku.isshelfdowns as IsShelfDown,
       s.StoresCode as StoresCode,
       s.InitialPrice as InitialPrice,
       nvl(p.price, s.SalesPrice) as SalesPrice,
       nvl(p.Price, 0) as ShopPrice,
       s.Salesprice as Price,
       s.IsCancel as IsCancel,
       s.IsCanAdJust as IsCanAdJust,
       info.Abbreviation as Abbreviation
  from base.WI_WareInfo info
  join base.WI_WareSku sku
    on info.productcode = sku.productcode
  join base.WI_WareStoresRelation s
    on sku.WareSkuCode = s.WareSkuCode
  left join base.WI_Unit u
    on info.unitcode = u.unitcode
--left join o2o_shopprice p on s.WareSkuCode=p.warecode and s.storescode=p.orgcode
  left join (select p.*
               from store.O2o_Shopprice p
               join store.O2o_Priceadjust pd
                 on p.refsheetcode = pd.sheetcode
              where sysdate >= pd.begintime
                and sysdate <= pd.endtime and pd.status=100) p
    on s.WareSkuCode = p.warecode
   and s.storescode = p.orgcode
 where s.iscancel = 0


/

