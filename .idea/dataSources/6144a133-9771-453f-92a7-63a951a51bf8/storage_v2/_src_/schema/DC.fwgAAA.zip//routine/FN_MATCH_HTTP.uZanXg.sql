create function fn_match_http(v_platform in varchar2,v_field in varchar2)
return number
as
  v_result number
begin
  if v_platform='pc' and (instr(v_field, '<link href="http://') or instr(v_field, 'src="http://') > 0)
    return 1;
  else
    return 0;
  end if;
end fn_match_http;

SELECT t.id FROM cms.cms_layout t where fn_match_http(t.platform,t.headtemplate)=1;
/

