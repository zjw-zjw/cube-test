create view VM_WHOLESALESETTLEMENTPRICE as
select a.warecode, a.price, b.SETTLEMENTPRICE, c.Cooperation
          from (select WareSkuCode as warecode, min(Price) as price
                  from ws.WS_WHOLESALEWAREPRICE
                 where Status = 1 and CusGradeCode='111'
                 group by WareSkuCode) a
          left join (select warecode, SETTLEMENTPRICE
                      from (select VWPNCODE,
                                   GRADE,
                                   WARECODE,
                                   AREACODE,
                                   AREANAME,
                                   RETAILPRICE,
                                   SETTLEMENTPRICE,
                                   ISAUTOREFRESH,
                                   SHELFSTATE,
                                   MINPRICE,
                                   rank() over(partition by WARECODE order by GRADE desc) n
                              from O2O.MMS_VALETWAREPRICENEW
                             where (GRADE, AREACODE) in ((0, '0')))
                     where n = 1) b
            on b.warecode = a.warecode
          left join (select WareSkuCode as warecode,
                           p.Cooperation
                      from O2O.O2O_GOODSRECOMMENDLEVEL g
                      left join O2O.O2O_PRICEREFRESHTYPECONFIG p
                        on p.PriceTypeId = g.PriceTypeId
                     where (p.ConfigId is null or
                           (p.StartTime <= sysdate and sysdate <= p.EndTime))
                       and p.Cooperation is not null) c
            on c.warecode = a.warecode
/

