create view DRP_VIEW_PUSHWARNLOG as
select a.tid,b.mid,a.createdate,a.updatedate,a.status,b.Mealitemcode,a.Platformname,a.Platformcode,a.Storename,
a.Storecode,b.Warename,b.Itemoutid,a.Message,b.Principal
 from DRP.DRP_ITEM_WARNLOG a inner join DRP.DRP_ITEM_MAPPING b on a.mid = b.mid
/

