create view OM_ORDERDETAILVIEW as
Select d.detailid,
       d.ordercode,
       d.warecode,
       d.qty,
       d.assignqty,
       d.consignqty,
       d.price,
       d.disprice,
       d.amt,
       d.kitcode,
       d.detailtype,
       d.detaildesc,
       w.isrx,
       s.warename As warenamePc,
       s.warename As warenameM,
       c.prmname,
       b.kitprice,
       b.kitwareqty,
        round(d.qty/k.qty,2) As kitqty,
       p.pic800 As picPC,
       m.pic800 As picM,
       p.rxtype As rxtypePc,
       m.rxtype As rxtypeM,
       s.status,
       nvl(k.iskeyware, 0) iskeyware,
       d.isvirtual,
       w.manufacturername,
       w.model,
       s.warename,
       u.unitname,
       d.plansenddate,
       d.invoiceamount,
       d.invoicecontentcode,
       d.sumdisprice,
       d.marketingcosts,
       d.origindetailid,
       d.tbmanager,
       d.netprice,
       d.ORISALEAMT,
       d.ORDERDISAMT,
       d.DISPLAYAMT,
       d.THIRDPARTYAMT,
       d.VIRTUALSHAREAMT,
       d.PREPAYSHAREAMT,
       d.SUMNETAMT,
       d.costprice,
       d.selecthavior,
       d.canexchange
  From om.om_orderdetail d
  Join om.wi_waresku s
    On d.warecode = s.wareskucode
  Join om.wi_wareinfo w
    On s.productcode = w.productcode
  Left Join om.wi_unit u
    On w.unitcode = u.unitcode
  Left Join om.wi_wareskum m
    On s.wareskucode = m.wareskucode
  Left Join om.wi_wareskupc p
    On s.wareskucode = p.wareskucode
  Left Join om.mm_kit b
    On d.kitcode = b.prmcode
  Left Join om.mm_kitsub k
    On b.prmcode = k.prmcode
   And d.warecode = k.warecode
  Left Join om.mm_promote c
    On b.prmcode = c.prmcode
/

