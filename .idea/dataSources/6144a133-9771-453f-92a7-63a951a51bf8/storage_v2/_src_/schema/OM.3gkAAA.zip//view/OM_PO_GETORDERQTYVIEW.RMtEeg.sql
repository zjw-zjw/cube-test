create view OM_PO_GETORDERQTYVIEW as
select k.warecode,nvl(k.frozenqty,0) as qty from OM_Stock k where k.frozenqty >0


/

