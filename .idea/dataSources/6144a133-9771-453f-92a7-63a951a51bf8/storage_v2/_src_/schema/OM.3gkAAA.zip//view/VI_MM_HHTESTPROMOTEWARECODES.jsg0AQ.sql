create view VI_MM_HHTESTPROMOTEWARECODES as
SELECT prmcode,nodeCode WareCode from MM_WareConfig wareConfig WHERE  wareConfig.nodetype = 1
UNION ALL
SELECT prmcode,wareskucode WareCode FROM MM_WareConfig cnConfig JOIN  wi_warechannelrelation channel ON cnConfig.Nodecode = channel.webchannelcode
WHERE  channel.wareskucode = cnConfig.nodecode AND cnConfig.nodetype = 2
UNION ALL
SELECT prmcode,wareskucode WareCode FROM MM_WareConfig skuConfig JOIN  wi_waresku sku  ON skuConfig.Nodecode = sku.Department
WHERE sku.wareskucode = skuConfig.nodecode AND skuConfig.nodetype = 3
/

