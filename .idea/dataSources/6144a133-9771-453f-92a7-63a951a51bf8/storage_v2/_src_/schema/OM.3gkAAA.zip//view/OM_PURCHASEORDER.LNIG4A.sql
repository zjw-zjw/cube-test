create view OM_PURCHASEORDER as
Select b.warecode WareCode,
      (Case When (Sum(b.orderqty - b.inqty)) > 0 Then (Sum(b.orderqty - b.inqty)) Else 0 End ) As  PurchaseQty,
       Min(case when b.delivertime > sysdate then b.delivertime else null end) DeliverTime
  From om.po_purorder a
  Join om.po_purordertotalsub b On a.sheetcode = b.sheetcode
 Where a.status in(100, 15)
 and (b.state = 0 Or b.state Is Null)
 and a.sheettype <>4
 Group By b.warecode
/

