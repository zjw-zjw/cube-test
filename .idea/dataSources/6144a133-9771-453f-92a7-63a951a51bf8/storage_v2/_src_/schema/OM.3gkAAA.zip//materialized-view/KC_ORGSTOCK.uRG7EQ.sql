create materialized view KC_ORGSTOCK
    refresh force on demand
as
Select A.WARECODE,
       Sum(A.ACTIVEQTY) As ORGSTOCKQTY,
       Sum(A.STOCKQTY) As TOTALSTOCKQTY
  From KC_ORGSTOCK@WMS_LNK A
 Where A.ORGCODE In ('001', '002')
 Group By A.WARECODE
/

