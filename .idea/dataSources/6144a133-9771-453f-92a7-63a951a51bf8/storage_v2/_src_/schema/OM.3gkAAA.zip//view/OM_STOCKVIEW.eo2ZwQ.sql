create view OM_STOCKVIEW as
Select a.id ID,
       c.warecode WareCode,
       nvl(a.stockqty, 0) StockQty,
       nvl(b.purchaseqty, 0) PurchaseQty,
       nvl(c.orderqty, 0) OrderQty,
       nvl(c.frozenqty, 0) FrozenQty,
       (nvl(d.totalstockqty, 0) + nvl(b.purchaseqty, 0) -
       nvl(c.frozenqty, 0)) ActiveQty,
       nvl(a.realactiveqty, 0) RealActiveQty,
       nvl(d.totalstockqty,0) TotalStockQty,
       d.orgstockqty,
       b.DeliverTime
  From om_stock c
  Left Join kc_stock a
    On c.warecode = a.warecode
  Left Join OM_PurchaseOrder b
    On c.warecode = b.warecode
  Left Join kc_orgstock d
    On c.warecode = d.warecode
/

comment on column OM_STOCKVIEW.ACTIVEQTY is '可用库存数量(totalstockqty+PurchaseQty-FrozenQty)'
/

comment on column OM_STOCKVIEW.REALACTIVEQTY is '花都仓库实物库存'
/

comment on column OM_STOCKVIEW.TOTALSTOCKQTY is '机构账面库存'
/

comment on column OM_STOCKVIEW.ORGSTOCKQTY is '机构实物库存'
/

