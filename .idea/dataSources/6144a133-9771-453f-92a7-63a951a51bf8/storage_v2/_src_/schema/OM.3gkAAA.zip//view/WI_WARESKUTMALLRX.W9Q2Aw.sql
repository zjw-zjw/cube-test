create view WI_WARESKUTMALLRX as
select a.numiid as numiid, a.wareskucode as wareskucode, a.saleprice as saleprice
from om.WI_WARESKUTMALLRX_base a
  where
    rowid  in
        (select min(rowid) as rowid1 from om.wi_wareskutmallrx_base group by wareskucode, saleprice having count(*) > 0)


/

